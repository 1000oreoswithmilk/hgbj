<?php

	sleep(5);
	
	echo 'Done';