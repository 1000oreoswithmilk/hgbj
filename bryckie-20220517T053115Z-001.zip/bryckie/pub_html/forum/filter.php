<?php
$page = 'forum';
require_once($_SERVER['DOCUMENT_ROOT']."/../private/header.php");

	echo '
	<div class="card-master-architect"><div class="card-image"></div><span>Planet Constructor</span></div>
	';
	
require_once($_SERVER['DOCUMENT_ROOT']."/../private/footer.php");