<?php
require_once($_SERVER['DOCUMENT_ROOT']."/../private/header.php");

	echo '
	
	';

require_once($_SERVER['DOCUMENT_ROOT']."/../private/footer.php");