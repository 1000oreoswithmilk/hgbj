<?php
$show_ads = false;
require_once($_SERVER['DOCUMENT_ROOT']."/../private/header.php");

	echo '
	<h4>Contact Us</h4>
	<div class="container border-r md-padding">
		General Support Inquiries: <a href="mailto:hello@brickplanet.com">hello@brickplanet.com</a>
		<br /><br />
		Ban Appeals: <a href="mailto:moderation@brickplanet.com">moderation@brickplanet.com</a>
	</div>
	';

require_once($_SERVER['DOCUMENT_ROOT']."/../private/footer.php");