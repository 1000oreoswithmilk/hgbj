<?php
$page = 'upgrade';
require_once($_SERVER['DOCUMENT_ROOT']."/../private/header.php");

	requireLogin();

	if (isset($_POST['choose_1'])) {

		$_SESSION['UpgradePlanChoice'] = 11;
		$_SESSION['UpgradeCheckoutPage'] = 1;

		header("Location: ".$serverName."/upgrade/checkout");
		die;

	} else if (isset($_POST['choose_2'])) {

		$_SESSION['UpgradePlanChoice'] = 12;
		$_SESSION['UpgradeCheckoutPage'] = 1;

		header("Location: ".$serverName."/upgrade/checkout");
		die;

	} else if (isset($_POST['choose_3'])) {

		$_SESSION['UpgradePlanChoice'] = 13;
		$_SESSION['UpgradeCheckoutPage'] = 1;

		header("Location: ".$serverName."/upgrade/checkout");
		die;

	} else if (isset($_POST['choose_4'])) {

		$_SESSION['UpgradePlanChoice'] = 14;
		$_SESSION['UpgradeCheckoutPage'] = 1;

		header("Location: ".$serverName."/upgrade/checkout");
		die;

	} else if (isset($_POST['choose_5']) && is_numeric($_POST['custom_credit_amount']) && $_POST['custom_credit_amount'] >= 500 && $_POST['custom_credit_amount'] <= 25000) {

		$_SESSION['UpgradePlanChoice'] = 15;
		$_SESSION['UpgradeCheckoutPage'] = 1;
		$_SESSION['UpgradeCustomCoins'] = (int)$_POST['custom_credit_amount'];

		header("Location: ".$serverName."/upgrade/checkout");
		die;

	}

	echo '
	<script>
		function updateCustomEstimate(amt) {
			if (amt < 500) {
				document.getElementById("custom_credit_amount").value = 500;
				amt = 500;
			} else if (amt > 25000) {
				document.getElementById("custom_credit_amount").value = 25000;
				amt = 25000;
			}
			document.getElementById("subtotal").innerHTML = parseFloat(amt / 100).toFixed(2);
		}
	</script>
	<h4>Credit Packages</h4>
	<div class="push-25"></div>
	<div class="grid-x grid-margin-x">
		<div class="large-3 medium-3 small-6 cell">
			<div class="container border-r">
				<div class="push-15"></div>
				<div class="text-center"><img src="'.$serverName.'/assets/images/credits.png"></div>
				<div class="upgrade-card-title">1,000 Credits</div>
				<div class="upgrade-card-price">$10.00</div>
				<div class="upgrade-card-button">
					<form action="" method="POST">
						<input type="submit" class="button button-green" name="choose_1" value="Choose">
					</form>
				</div>
			</div>
			<div class="push-50 show-for-small-only"></div>
		</div>
		<div class="large-3 medium-3 small-6 cell">
			<div class="container border-r">
				<div class="push-15"></div>
				<div class="text-center"><img src="'.$serverName.'/assets/images/credits.png"></div>
				<div class="upgrade-card-title">4,500 Credits</div>
				<div class="upgrade-card-price">$45.00</div>
				<div class="upgrade-card-button">
					<form action="" method="POST">
						<input type="submit" class="button button-green" name="choose_2" value="Choose">
					</form>
				</div>
			</div>
		</div>
		<div class="large-3 medium-3 small-6 cell">
			<div class="container border-r">
				<div class="push-15"></div>
				<div class="text-center"><img src="'.$serverName.'/assets/images/credits.png"></div>
				<div class="upgrade-card-title">7,500 Credits</div>
				<div class="upgrade-card-price">$75.00</div>
				<div class="upgrade-card-button">
					<form action="" method="POST">
						<input type="submit" class="button button-green" name="choose_3" value="Choose">
					</form>
				</div>
			</div>
		</div>
		<div class="large-3 medium-3 small-6 cell">
			<div class="container border-r">
				<div class="push-15"></div>
				<div class="text-center"><img src="'.$serverName.'/assets/images/credits.png"></div>
				<div class="upgrade-card-title">10,000 Credits</div>
				<div class="upgrade-card-price">$100.00</div>
				<div class="upgrade-card-button">
					<form action="" method="POST">
						<input type="submit" class="button button-green" name="choose_4" value="Choose">
					</form>
				</div>
			</div>
		</div>
	</div>
	<div class="push-50"></div>
	<div class="text-center">
		<button type="button" class="button button-grey" style="margin:0 auto;" data-open="CustomAmount">Custom Amount</button>
	</div>
	<div class="reveal item-modal" id="CustomAmount" data-reveal data-animation-in="fade-in" data-animation-out="fade-out">
		<form action="" method="POST">
			<div class="grid-x grid-margin-x align-middle">
				<div class="auto cell no-margin">
					<div class="modal-title">Buy a custom amount of Credits</div>
				</div>
				<div class="shrink cell no-margin">
					<button class="close-button" data-close aria-label="Close modal" type="button"><span aria-hidden="true">&times;</span></button>
				</div>
			</div>
			<div class="push-15"></div>
			<div>Please choose the amount of Credits you wish to purchase. Minimum is <strong>500</strong>.</div>
			<div class="push-15"></div>
			<input type="text" name="custom_credit_amount" id="custom_credit_amount" class="normal-input" placeholder="Credits" value="500" onchange="updateCustomEstimate(this.value)">
			<div class="push-5"></div>
			<div class="sub">Your estimated total in USD will be <strong>$<font id="subtotal">5.00</font> USD</strong></div>
			<div class="push-25"></div>
			<div align="center">
				<input type="submit" class="button button-green store-button inline-block" name="choose_5" value="Checkout">
				<input type="button" data-close class="button button-grey store-button inline-block" value="Go back">
			</div>
		</form>
	</div>
	';

require_once($_SERVER['DOCUMENT_ROOT']."/../private/footer.php");
