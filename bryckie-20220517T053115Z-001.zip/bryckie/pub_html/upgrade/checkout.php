<?php
$page = 'upgrade';
require_once($_SERVER['DOCUMENT_ROOT']."/../private/header.php");

	if (!isset($_SESSION['UpgradePlanChoice'])) {
		
		header("Location: ".$serverName."/upgrade/");
		die;
		
	} else {
		
		$CheckoutPage = !isset($_SESSION['UpgradeCheckoutPage']) ? 1 : $_SESSION['UpgradeCheckoutPage'];
		$CheckoutPlan = ($_SESSION['UpgradePlanChoice'] != 1 && $_SESSION['UpgradePlanChoice'] != 2 && $_SESSION['UpgradePlanChoice'] != 3 && $_SESSION['UpgradePlanChoice'] != 4 && $_SESSION['UpgradePlanChoice'] != 5 && $_SESSION['UpgradePlanChoice'] != 6 && $_SESSION['UpgradePlanChoice'] != 7 && $_SESSION['UpgradePlanChoice'] != 8 && $_SESSION['UpgradePlanChoice'] != 9 && $_SESSION['UpgradePlanChoice'] != 10 && $_SESSION['UpgradePlanChoice'] != 11 && $_SESSION['UpgradePlanChoice'] != 12 && $_SESSION['UpgradePlanChoice'] != 13 && $_SESSION['UpgradePlanChoice'] != 14 && $_SESSION['UpgradePlanChoice'] != 15) ? 1 : $_SESSION['UpgradePlanChoice'];
		
		if ($CheckoutPage == 1) {
		
			if (!empty($_POST['method']) && ($_POST['method'] == 1 || $_POST['method'] == 3)) {
				
				$_SESSION['UpgradeCheckoutPage'] = 2;
				$_SESSION['UpgradeCheckoutMethod'] = (int)$_POST['method'];
				
				header("Location: ".$serverName."/upgrade/checkout");
				die;
				
			}
			
			if ($CheckoutPlan == 1 && $myU->VIP >= 1 || $CheckoutPlan == 2 && $myU->VIP >= 2 || $CheckoutPlan == 3 && $myU->VIP >= 3) {
				
				unset($_SESSION['UpgradeCheckoutPage']);
				unset($_SESSION['UpgradeCheckoutMethod']);
				header("Location: ".$serverName."/upgrade/");
				die;
				
			}
			
			switch ($CheckoutPlan) {
				case 1:
					// Brick Builder
					$PaypalID = '59FTLDA2A9JVU';
					$PlanName = 'Brick Builder (month)';
					$PlanPrice = 4.95;
					break;
				case 2:
					// Planet Constructor
					$PaypalID = 'BT98NYJGNWX84';
					$PlanName = 'Planet Constructor (month)';
					$PlanPrice = 11.95;
					break;
				case 3:
					// Master Architect
					$PaypalID = '6WTN4ZKKBK94Y';
					$PlanName = 'Master Architect (month)';
					$PlanPrice = 18.95;
					break;
				case 4:
					// 1,000 Bits
					$PaypalID = 'PR3ZTZMCEGAGL';
					$PlanPrice = 0.99;
					break;
				case 5:
					// 5,000 Bits
					$PaypalID = 'NCV5Z4FR6PHCN';
					$PlanPrice = 4.99;
					break;
				case 6:
					// 10,000 Bits
					$PaypalID = 'QC8FBVZB9SY2G';
					$PlanPrice = 9.99;
					break;
				case 7:
					// 25,000 Bits
					$PaypalID = 'SRRV7V59DGR7C';
					$PlanPrice = 24.99;
					break;
				case 8:
					// 51,000 Bits
					$PaypalID = 'XN7WG3VWHSQUU';
					$PlanPrice = 49.99;
					break;
				case 9:
					// 105,000 Bits
					$PaypalID = 'QUB8XEQ7Q8PT2';
					$PlanPrice = 99.99;
					break;
				case 10:
					// 160,000 Bits
					$PaypalID = 'KNPSU4DE2DDB6';
					$PlanPrice = 149.99;
					break;
				case 11:
					// 1,000 Credits
					$PaypalID = 'TEAC49EY6MTUW';
					$PlanCredits = 1000;
					break;
				case 12:
					// 4,500 Credits
					$PaypalID = '3KHMRPJ6YXZUS';
					$PlanCredits = 4500;
					break;
				case 13:
					// 7,500 Credits
					$PaypalID = 'YEBBY9S88C6MQ';
					$PlanCredits = 7500;
					break;
				case 14:
					// 10,000 Credits
					$PaypalID = 'Z95TUTCK9P75S';
					$PlanCredits = 10000;
					break;
				case 15:
					// Custom Credits
					$PlanCredits = (int)$_SESSION['UpgradeCustomCoins'];
					$CustomCredits = 1;
					$PlanName = ''.number_format($PlanCredits).' Credits';
					$PlanPrice = number_format(($PlanCredits/100), 2);
					break;
			}
			
			switch ($myU->VIP) {
				case 1:
					$CurrentPrice = '4.95';
					break;
				case 2:
					$CurrentPrice = '11.95';
					break;
				case 3:
					$CurrentPrice = '18.95';
					break;
			}
			
			if ($myU->VIP == 1 && $CheckoutPlan == 2 || $myU->VIP == 2 && $CheckoutPlan == 3) {
				$CalculateDays = round((($myU->VIP_Expires - time())/86400));
				$CalculateDays = $CalculateDays/31;
				$ProRateCredit = number_format(($CurrentPrice*$CalculateDays), 2);
				$PlanPrice = $PlanPrice - $ProRateCredit;
				$TimeExtension = 1;
			} else if ($myU->VIP == 1 && $CheckoutPlan == 3) {
				$CalculateDays = round((($myU->VIP_Expires - time())/86400));
				$CalculateDays = $CalculateDays/31;
				$ProRateCredit = number_format(($CurrentPrice*$CalculateDays), 2);
				$PlanPrice = $PlanPrice - $ProRateCredit;
				$TimeExtension = 1;
			}
			
			if (isset($PlanCredits) && $PlanCredits < 500 || $PlanCredits > 25000) {
				
				unset($_SESSION['UpgradeCheckoutPage']);
				unset($_SESSION['UpgradeCheckoutMethod']);
				unset($_SESSION['UpgradeCustomCoins']);
				header("Location: ".$serverName."/upgrade/");
				die;
				
			}
			
			echo '
			<div class="grid-x grid-margin-x">
				<div class="large-9 upgrade-offset cell">
					<h4>Checkout</h4>
					<div class="container border-r md-padding">
						<div class="upgrade-checkout-one-text">Please choose your payment method.</div>
						<form action="" method="POST" class="upgrade-checkout-one">
							<div><input type="radio" name="method" id="method_01" value="1" onchange="switchMethod(this.value)"><label for="method_01" class="upgrade-checkout-one-cards"><i class="fa fa-credit-card"></i><span>Debit/Credit Card</span></label></div>
							<div><input type="radio" name="method" id="method_02" value="2" onchange="switchMethod(this.value)"><label for="method_02" class="upgrade-checkout-one-cards"><i class="fa fa-paypal" style="color:#009cde;"></i><span>PayPal</span></label></div>
							';
							
							if (!isset($PlanCredits) && $myU->CurrencyCredits >= ($PlanPrice*100)) {
							
								echo '
								<div><input type="radio" name="method" id="method_03" value="3" onchange="switchMethod(this.value)"><label for="method_03">Account Credits</label></div>
								';
							
							}
							
							echo '
							<div id="button"><input type="submit" class="button button-green" value="Next" disabled></div>
						</form>
					</div>
				</div>
			</div>
			';
			
			echo '
			<script>
				function switchMethod(Id) {
					if (Id == 1 || Id == 3) {
						document.getElementById("button").innerHTML = "<input type=\"submit\" class=\"button button-green\" value=\"Next\">";
					} else if (Id == 2) {
						';
						
						if (isset($CustomCredits)) {
						
							echo '
							document.getElementById("button").innerHTML = "</form><form action=\"https://www.paypal.com/cgi-bin/webscr\" method=\"post\"><input type=\"hidden\" name=\"business\" value=\"corporate@brickplanet.com\"><input type=\"hidden\" name=\"cmd\" value=\"_xclick\"><input type=\"hidden\" name=\"item_name\" value=\"'.$PlanName.'\"><input type=\"hidden\" name=\"amount\" value=\"'.number_format($PlanPrice, 2).'\"><input type=\"hidden\" name=\"currency_code\" value=\"USD\"><input type=\"hidden\" name=\"custom\" value=\"'.$myU->ID.'\"><input type=\"submit\" value=\"Next\" class=\"button button-green\">";
							';
						
						} else if (!isset($TimeExtension)) {
						
							echo '
							document.getElementById("button").innerHTML = "</form><form action=\"https://www.paypal.com/cgi-bin/webscr\" method=\"post\" target=\"_top\"><input type=\"hidden\" name=\"cmd\" value=\"_s-xclick\"><input type=\"hidden\" name=\"hosted_button_id\" value=\"'.$PaypalID.'\"><input type=\"hidden\" name=\"custom\" value=\"'.$myU->ID.'\"><input type=\"submit\" value=\"Next\" class=\"button button-green\">";
							';
						
						} else {
							
							echo '
							document.getElementById("button").innerHTML = "</form><form action=\"https://www.paypal.com/cgi-bin/webscr\" method=\"post\"><input type=\"hidden\" name=\"business\" value=\"corporate@brickplanet.com\"><input type=\"hidden\" name=\"cmd\" value=\"_xclick\"><input type=\"hidden\" name=\"item_name\" value=\"'.$PlanName.'\"><input type=\"hidden\" name=\"amount\" value=\"'.number_format($PlanPrice, 2).'\"><input type=\"hidden\" name=\"currency_code\" value=\"USD\"><input type=\"hidden\" name=\"custom\" value=\"'.$myU->ID.'\"><input type=\"submit\" value=\"Next\" class=\"button button-green\">";
							';
							
						}
						
						echo '
					}
				}
			</script>
			';
		
		} else if ($CheckoutPage == 2 && !empty($_SESSION['UpgradeCheckoutMethod']) && ($_SESSION['UpgradeCheckoutMethod'] == 1 || $_SESSION['UpgradeCheckoutMethod'] == 3)) {
			
			if ($CheckoutPlan == 1 && $myU->VIP >= 1 || $CheckoutPlan == 2 && $myU->VIP >= 2 || $CheckoutPlan == 3 && $myU->VIP >= 3) {
				
				unset($_SESSION['UpgradeCheckoutPage']);
				unset($_SESSION['UpgradeCheckoutMethod']);
				header("Location: ".$serverName."/upgrade/checkout");
				die;
				
			}
			
			$VIPTime = time() + 2678400;
			
			switch ($CheckoutPlan) {
				case 1:
					$PlanName = 'Brick Builder (monthly)';
					$PlanPrice = '4.95';
					$PlanCoins = 100;
					break;
				case 2:
					$PlanName = 'Planet Constructor (monthly)';
					$PlanPrice = '11.95';
					$PlanCoins = 200;
					break;
				case 3:
					$PlanName = 'Master Architect (monthly)';
					$PlanPrice = '18.95';
					$PlanCoins = 300;
					break;
				case 4:
					$PlanName = '1,000 Bits';
					$PlanPrice = '0.99';
					$PlanCoins = 1000;
					break;
				case 5:
					$PlanName = '5,000 Bits';
					$PlanPrice = '4.99';
					$PlanCoins = 5000;
					break;
				case 6:
					$PlanName = '10,000 Bits';
					$PlanPrice = '9.99';
					$PlanCoins = 10000;
					break;
				case 7:
					$PlanName = '25,000 Bits';
					$PlanPrice = '24.99';
					$PlanCoins = 25000;
					break;
				case 8:
					$PlanName = '51,000 Bits';
					$PlanPrice = '49.99';
					$PlanCoins = 51000;
					break;
				case 9:
					$PlanName = '105,000 Bits';
					$PlanPrice = '99.99';
					$PlanCoins = 105000;
					break;
				case 10:
					$PlanName = '160,000 Bits';
					$PlanPrice = '149.99';
					$PlanCoins = 160000;
					break;
				case 11:
					$PlanName = '1,000 Credits';
					$PlanPrice = '10.00';
					$PlanCredits = 1000;
					break;
				case 12:
					$PlanName = '4,500 Credits';
					$PlanPrice = '45.00';
					$PlanCredits = 4500;
					break;
				case 13:
					$PlanName = '7,500 Credits';
					$PlanPrice = '75.00';
					$PlanCredits = 7500;
					break;
				case 14:
					$PlanName = '10,000 Credits';
					$PlanPrice = '100.00';
					$PlanCredits = 10000;
					break;
				case 15:
					// Custom Credits
					$PlanCredits = (int)$_SESSION['UpgradeCustomCoins'];
					$CustomCredits = 1;
					$PlanName = ''.number_format($PlanCredits).' Credits';
					$PlanPrice = number_format(($PlanCredits/100), 2);
					break;
			}
			
			switch ($myU->VIP) {
				case 1:
					$CurrentPrice = '4.95';
					break;
				case 2:
					$CurrentPrice = '11.95';
					break;
				case 3:
					$CurrentPrice = '18.95';
					break;
			}
			
			if ($myU->VIP == 1 && $CheckoutPlan == 2 || $myU->VIP == 2 && $CheckoutPlan == 3) {
				$CalculateDays = round((($myU->VIP_Expires - time())/86400));
				$CalculateDays = $CalculateDays/31;
				$ProRateCredit = number_format(($CurrentPrice*$CalculateDays), 2);
				$PlanPrice = $PlanPrice - $ProRateCredit;
				$TimeExtension = 1;
			} else if ($myU->VIP == 1 && $CheckoutPlan == 3) {
				$CalculateDays = round((($myU->VIP_Expires - time())/86400));
				$CalculateDays = $CalculateDays/31;
				$ProRateCredit = number_format(($CurrentPrice*$CalculateDays), 2);
				$PlanPrice = $PlanPrice - $ProRateCredit;
				$TimeExtension = 1;
			}
			
			if (isset($PlanCredits) && $PlanCredits < 500 || $PlanCredits > 25000) {
				
				unset($_SESSION['UpgradeCheckoutPage']);
				unset($_SESSION['UpgradeCheckoutMethod']);
				unset($_SESSION['UpgradeCustomCoins']);
				header("Location: ".$serverName."/upgrade/");
				die;
				
			}
			
			if ($_SESSION['UpgradeCheckoutMethod'] == 1) {
			
				require_once('vendor/autoload.php');
				
				if (isset($_POST['stripeToken']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
					
					\Stripe\Stripe::setApiKey('sk_live_fYu99GFyStXZ8vgBpIL5gbOj');
					$token = $_POST['stripeToken'];
					
					try {
						
						if (($CheckoutPlan == 1 || $CheckoutPlan == 2 || $CheckoutPlan == 3) && !isset($TimeExtension)) {
						
							if (empty($myU->StripeKey)) {
								
								$customer = \Stripe\Customer::create(array(
									"source" => $token,
									"email" => "{$myU->Email}",
									"plan" => $CheckoutPlan,
									"description" => 'User ID: '.$myU->ID.'',
								));
								
								$updateKey = $db->prepare("UPDATE User SET StripeKey = '".$customer->id."' WHERE ID = ".$myU->ID."");
								$updateKey->execute();
								
								$SubscriptionID = $customer->subscriptions->data[0]->id;
								
							} else {
								
								$customer = \Stripe\Customer::retrieve($myU->StripeKey);
								
								if ($customer->subscriptions->total_count > 0) {
									
									$customer->cancelSubscription();
									
								}
								
								$customer->source = $token;
								$customer->save();
								
								$subscription = \Stripe\Subscription::create(array(
									"customer" => $myU->StripeKey,
									"plan" => $CheckoutPlan,
									"prorate" => false
								));
								
								$SubscriptionID = $subscription->id;
								
							}
							
							if ($myU->UpgradesCount == 0) {
								
								$Update = $db->prepare("UPDATE User SET CurrencyCoins = CurrencyCoins + 500 WHERE ID = ".$myU->ID."");
								$Update->execute();
								
							}
							
							$Name = $customer->sources->data[0]->name;
							$Address = !empty($customer->sources->data[0]->address_line2) ? ($customer->sources->data[0]->address_line1 . '<br />' . $customer->sources->data[0]->address_line2) : $customer->sources->data[0]->address_line1;
							$City = $customer->sources->data[0]->address_city;
							$State = $customer->sources->data[0]->address_state;
							$Country = $customer->sources->data[0]->country;
							$LastFour = $customer->sources->data[0]->last4;
							
						
						} else {
						
							$charge = \Stripe\Charge::create(array(
							"amount" => $PlanPrice*100, // amount in cents, again
							"currency" => "usd",
							"source" => $token,
							"description" => 'User ID: '.$myU->ID.', Plan Name: '.$PlanName.''
							));
							
							$Name = $charge->source->name;
							$Address = !empty($charge->source->address_line2) ? ($charge->source->address_line1 . '<br />' . $charge->source->address_line2) : $charge->source->address_line1;
							$City = $charge->source->address_city;
							$State = $charge->source->address_state;
							$Country = $charge->source->country;
							$LastFour = $charge->source->last4;
							$SubscriptionID = $charge->id;
						
						}
						
						$Insert = $db->prepare("INSERT INTO UserPaymentHistory (UserID, PlanID, PaymentType, TimePayment, PayerName, PayerEmail, PayerAddress, PayerCity, PayerState, PayerCountry, TransactionID, SubscriptionID, LastFour) VALUES(".$myU->ID.", ".$CheckoutPlan.", 0, ".time().", ?, '".$myU->Email."', ?, ?, ?, ?, ?, ?, ?)");
						$Insert->bindValue(1, $Name, PDO::PARAM_STR);
						$Insert->bindValue(2, $Address, PDO::PARAM_STR);
						$Insert->bindValue(3, $City, PDO::PARAM_STR);
						$Insert->bindValue(4, $State, PDO::PARAM_STR);
						$Insert->bindValue(5, $Country, PDO::PARAM_STR);
						$Insert->bindValue(6, $SubscriptionID, PDO::PARAM_STR);
						$Insert->bindValue(7, $SubscriptionID, PDO::PARAM_STR);
						$Insert->bindValue(8, $LastFour, PDO::PARAM_STR);
						$Insert->execute();
						
						if (($CheckoutPlan == 1 || $CheckoutPlan == 2 || $CheckoutPlan == 3) && !isset($TimeExtension)) {
							
							$Update = $db->prepare("UPDATE User SET CurrencyCoins = CurrencyCoins + ".$PlanCoins.", NextUpgradeCoinPay = ".(time() + 86400).", VIP = ".$CheckoutPlan.", VIP_Recurring = 1, VIP_Expires = ".$VIPTime." WHERE ID = ".$myU->ID."");
							$Update->execute();
							
							$Insert = $db->prepare("INSERT INTO UserBadge (UserID, AchievementID) VALUES(".$myU->ID.", ".($CheckoutPlan+8).")");
							$Insert->execute();
							
							// Discord verification
							if ($myU->DiscordId > 0 && $myU->VIP == 0) {
								$ch = curl_init();
								curl_setopt($ch, CURLOPT_URL, 'http://discordapi.brickplanet.com/modify-user-vip?userId='.$myU->DiscordId.'&action=add-role&level=' . $CheckoutPlan);
								curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
								$result = curl_exec($ch);
								curl_close($ch);
							} else if ($myU->DiscordId > 0 && $myU->VIP > 0) {
								$ch = curl_init();
								curl_setopt($ch, CURLOPT_URL, 'http://discordapi.brickplanet.com/modify-user-vip?userId='.$myU->DiscordId.'&action=change-role&level=' . $myU->VIP . '&newlevel=' . $CheckoutPlan);
								curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
								$result = curl_exec($ch);
								curl_close($ch);
							}
							
							if ($CheckoutPlan == 1) {
								
								$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 19141");
								$Count->execute();
								$Count = $Count->fetchColumn();
								
								if ($Count == 0) {
									$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 19141, ".time().")");
									$Insert->execute();
								}
								
							} else if ($CheckoutPlan == 2) {
								
								$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18595");
								$Count->execute();
								$Count = $Count->fetchColumn();
								
								if ($Count == 0) {
									$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18595, ".time().")");
									$Insert->execute();
								}
								
								$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18611");
								$Count->execute();
								$Count = $Count->fetchColumn();
								
								if ($Count == 0) {
									$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18611, ".time().")");
									$Insert->execute();
								}
								
							} else if ($CheckoutPlan == 3) {
								
								$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18555");
								$Count->execute();
								$Count = $Count->fetchColumn();
								
								if ($Count == 0) {
									$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18555, ".time().")");
									$Insert->execute();
								}
								
								$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18562");
								$Count->execute();
								$Count = $Count->fetchColumn();
								
								if ($Count == 0) {
									$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18562, ".time().")");
									$Insert->execute();
								}
								
								$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18586");
								$Count->execute();
								$Count = $Count->fetchColumn();
								
								if ($Count == 0) {
									$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18586, ".time().")");
									$Insert->execute();
								}
								
								$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18589");
								$Count->execute();
								$Count = $Count->fetchColumn();
								
								if ($Count == 0) {
									$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18589, ".time().")");
									$Insert->execute();
								}
								
							}
							
						} else if (($CheckoutPlan == 1 || $CheckoutPlan == 2 || $CheckoutPlan == 3) && isset($TimeExtension) && $myU->VIP_Recurring == 1) {
							
							$Update = $db->prepare("UPDATE User SET CurrencyCoins = CurrencyCoins + ".$PlanCoins.", NextUpgradeCoinPay = ".(time() + 86400).", VIP = ".$CheckoutPlan.", VIP_Recurring = 0, VIP_Expires = ".$VIPTime." WHERE ID = ".$myU->ID."");
							$Update->execute();
							
							$Insert = $db->prepare("INSERT INTO UserBadge (UserID, AchievementID) VALUES(".$myU->ID.", ".($CheckoutPlan+8).")");
							$Insert->execute();
							
							// Discord verification
							if ($myU->DiscordId > 0 && $myU->VIP == 0) {
								$ch = curl_init();
								curl_setopt($ch, CURLOPT_URL, 'http://discordapi.brickplanet.com/modify-user-vip?userId='.$myU->DiscordId.'&action=add-role&level=' . $CheckoutPlan);
								curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
								$result = curl_exec($ch);
								curl_close($ch);
							} else if ($myU->DiscordId > 0 && $myU->VIP > 0) {
								$ch = curl_init();
								curl_setopt($ch, CURLOPT_URL, 'http://discordapi.brickplanet.com/modify-user-vip?userId='.$myU->DiscordId.'&action=change-role&level=' . $myU->VIP . '&newlevel=' . $CheckoutPlan);
								curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
								$result = curl_exec($ch);
								curl_close($ch);
							}
							
							if ($CheckoutPlan == 1) {
								
								$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 19141");
								$Count->execute();
								$Count = $Count->fetchColumn();
								
								if ($Count == 0) {
									$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 19141, ".time().")");
									$Insert->execute();
								}
								
							} else if ($CheckoutPlan == 2) {
								
								$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18595");
								$Count->execute();
								$Count = $Count->fetchColumn();
								
								if ($Count == 0) {
									$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18595, ".time().")");
									$Insert->execute();
								}
								
								$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18611");
								$Count->execute();
								$Count = $Count->fetchColumn();
								
								if ($Count == 0) {
									$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18611, ".time().")");
									$Insert->execute();
								}
								
							} else if ($CheckoutPlan == 3) {
								
								$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18555");
								$Count->execute();
								$Count = $Count->fetchColumn();
								
								if ($Count == 0) {
									$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18555, ".time().")");
									$Insert->execute();
								}
								
								$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18562");
								$Count->execute();
								$Count = $Count->fetchColumn();
								
								if ($Count == 0) {
									$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18562, ".time().")");
									$Insert->execute();
								}
								
								$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18586");
								$Count->execute();
								$Count = $Count->fetchColumn();
								
								if ($Count == 0) {
									$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18586, ".time().")");
									$Insert->execute();
								}
								
								$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18589");
								$Count->execute();
								$Count = $Count->fetchColumn();
								
								if ($Count == 0) {
									$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18589, ".time().")");
									$Insert->execute();
								}
								
							}
							
							$query = $db->prepare("SELECT PaymentType, SubscriptionID FROM UserPaymentHistory WHERE UserID = ".$myU->ID." AND PlanID IN(1, 2, 3) ORDER BY TimePayment DESC LIMIT 1");
							$query->execute();
							
							if ($query->rowCount() > 0) {
								
								$q = $query->fetch(PDO::FETCH_OBJ);
								
								if ($q->PaymentType == 0) {
									
									require_once('/var/www/html/root/html/upgrade/vendor/autoload.php');
									
									$customer = \Stripe\Customer::retrieve($myU->StripeKey);
									
									if ($customer->subscriptions->total_count > 0) {
										
										$customer->cancelSubscription();
										
									}
									
								} else if ($q->PaymentType == 1) {
									
									CancelPaypalSubscription($q->SubscriptionID, 'Cancel');
									
								}
							
							}
							
							
						} else if (isset($PlanCoins)) {
							
							$Update = $db->prepare("UPDATE User SET CurrencyCoins = CurrencyCoins + ".$PlanCoins." WHERE ID = ".$myU->ID."");
							$Update->execute();
							
						} else if (isset($PlanCredits)) {
							
							$Update = $db->prepare("UPDATE User SET CurrencyCredits = CurrencyCredits + ".$PlanCredits." WHERE ID = ".$myU->ID."");
							$Update->execute();
							
						}
						
						$cache->delete($myU->ID);
						
						header("Location: ".$serverName."/upgrade/success/");
						die;
						
					} catch(\Stripe\Error\Card $e) {
					
						$errorMessage = $e->getMessage();
					
					}
					
				}
				
				echo '
				<form action="" method="POST" id="payment-form">
					<div class="grid-x grid-margin-x">
						<div class="large-9 cell">
							';
							
							if (isset($errorMessage)) {
								
								echo '<div class="error-message">'.$errorMessage.'</div>';
								
							}
							
							echo '
							<h5>Payment details</h5>
							<div class="container border-r md-padding upgrade-checkout-cc">
								<div class="grid-x grid-margin-x">
									<div class="large-12 cell">
										<label for="name_on_card">Name on card</label>
										<input type="text" class="normal-input" id="name_on_card" data-stripe="name">
									</div>
									<div class="large-12 cell">
										<div class="push-25"></div>
										<label for="full_address">Full address</label>
										<input type="text" class="normal-input" id="full_address" data-stripe="address_line1">
									</div>
								</div>
								<div class="grid-x grid-margin-x">
									<div class="large-5 cell">
										<div class="push-25"></div>
										<label for="city">City</label>
										<input type="text" class="normal-input" id="city" data-stripe="address_city">
									</div>
									<div class="large-4 cell">
										<div class="push-25"></div>
										<label for="state">State/Province</label>
										<input type="text" class="normal-input"  id="state" data-stripe="address_state">
									</div>
									<div class="large-3 cell">
										<div class="push-25"></div>
										<label for="postal_code">Postal Code</label>
										<input type="text" class="normal-input" id="postal_code" data-stripe="address_zip">
									</div>
									<div class="large-12 cell">
										<div class="push-25"></div>
										<label for="country">Country</label>
										<input type="text" class="normal-input" id="country" data-stripe="address_country">
									</div>
								</div>
								<div class="upgrade-checkout-cc-divider"></div>
								<div class="grid-x grid-margin-x">
									<div class="large-5 cell">
										<label for="credit_card_number">Credit card number</label>
										<input type="text" class="normal-input" id="credit_card_number" data-stripe="number">
									</div>
									<div class="large-2 cell">
										<label for="cvc">CVC</label>
										<input type="text" class="normal-input" id="cvc" data-stripe="exp-month">
									</div>
									<div class="large-5 cell">
										<div class="grid-x grid-margin-x">
											<div class="large-6 cell">
												<label for="exp_date">Expiration date</label>
												<select class="normal-input" data-stripe="exp-month">
													<option value="1">01</option>
													<option value="2">02</option>
													<option value="3">03</option>
													<option value="4">04</option>
													<option value="5">05</option>
													<option value="6">06</option>
													<option value="7">07</option>
													<option value="8">08</option>
													<option value="9">09</option>
													<option value="10">10</option>
													<option value="11">11</option>
													<option value="12">12</option>
												</select>
											</div>
											<div class="large-6 cell">
												<label>&nbsp;</label>
												<select class="normal-input" data-stripe="exp-year">
													';
													
													for ($i = date('Y'); $i < date('Y')+16; $i++) {
													
														echo '<option value="'.$i.'">'.$i.'</option>';
													
													}
													
													echo '
												</select>
											</div>
										</div>
									</div>
								</div>
								<div class="grid-x grid-margin-x">
									<div class="auto cell">
										<div class="push-25"></div>
										<div class="upgrade-checkout-footnotes">Credit card payments are processed through our merchant <a href="https://stripe.com/docs/security/stripe" target="_blank">Stripe</a>. Do not use a debit/credit card without the cardholder\'s explicit authorization. Fraudulent payments are subject to account termination and we will report the event(s) to law enforcement, if necessary.</div>
									</div>
								</div>
							</div>
						</div>
						<div class="large-3 cell">
							<h5>You\'re buying</h5>
							<div class="container border-r md-padding">
								<div class="ur-buying-title">'.$PlanName.'</div>
								<div class="ur-buying-divider"></div>
								';
								
								if (isset($TimeExtension)) {
									
									echo '
									<div class="grid-x grid-margin-x">
										<div class="auto cell no-margin">
											<strong>Original amount</strong>
										</div>
										<div class="shrink cell right no-margin">
											$'.number_format($PlanPrice+$ProRateCredit, 2).' USD
										</div>
									</div>
									<div class="grid-x grid-margin-x">
										<div class="auto cell no-margin">
											<strong>Adjustment</strong>
										</div>
										<div class="shrink cell right no-margin">
											- $'.number_format($ProRateCredit, 2).' USD
										</div>
									</div>
									<div class="ur-buying-divider"></div>
									';
									
								}
								
								echo '
								<div class="grid-x grid-margin-x">
									<div class="auto cell no-margin">
										<strong>Total due</strong>
									</div>
									<div class="shrink cell right no-margin">
										$'.number_format($PlanPrice, 2).' USD
									</div>
								</div>
								';
								
								if (isset($TimeExtension)) {
									
									echo '
									<div class="ur-buying-divider"></div>
									<div class="upgrade-checkout-footnotes">Because you are upgrading to a higher VIP package, it will not automatically renew. This plan is set to expire on <strong>'.date('m/d/Y', $VIPTime).'</strong>.</div>
									';
									
								} else if ($CheckoutPlan == 1 || $CheckoutPlan == 2 || $CheckoutPlan == 3) {
									
									echo '
									<div class="ur-buying-divider"></div>
									<div class="upgrade-checkout-footnotes">This plan is set to auto renew on <strong>'.date('m/d/Y', $VIPTime).'</strong>. However, you will have the option to cancel renewal any time in your account settings.</div>
									';
									
								}
								
								echo '
							</div>
							<div class="push-25"></div>
							<div class="text-center"><button type="submit" class="button button-green" style="display:inline-block;">Complete</button></div>
						</div>
					</div>
				</form>
				<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
				<script type="text/javascript">
					  // This identifies your website in the createToken call below
					  Stripe.setPublishableKey(\'pk_live_FMPLZYNmlUmE2Rv55VR1nCrA\');
					  // ...
					 jQuery(function($) {
					  $(\'#payment-form\').submit(function(event) {
						var $form = $(this);

						// Disable the submit button to prevent repeated clicks
						$form.find(\'button\').prop(\'disabled\', true);

						Stripe.card.createToken($form, stripeResponseHandler);

						// Prevent the form from submitting with the default action
						return false;
					  });
					});
					function stripeResponseHandler(status, response) {
					  var $form = $(\'#payment-form\');

					  if (response.error) {
						// Show the errors on the form
						$form.find(\'.payment-errors\').text(response.error.message);
						$form.find(\'button\').prop(\'disabled\', false);
					  } else {
						// response contains id and card, which contains additional card details
						var token = response.id;
						// Insert the token into the form so it gets submitted to the server
						$form.append($(\'<input type="hidden" name="stripeToken" />\').val(token));
						// and submit
						$form.get(0).submit();
					  }
					};
				</script>
				';
			
			} else if ($_SESSION['UpgradeCheckoutMethod'] == 3 && $myU->CurrencyCredits >= (number_format($PlanPrice, 2)*100) && !isset($PlanCredits)) {
				
				if (isset($_POST['submit'])) {
					
					if (($CheckoutPlan == 1 || $CheckoutPlan == 2 || $CheckoutPlan == 3) && !isset($TimeExtension)) {
						
						if (isset($TimeExtension) && $myU->VIP_Recurring == 1) {
							
							$query = $db->prepare("SELECT PaymentType, SubscriptionID FROM UserPaymentHistory WHERE UserID = ".$myU->ID." AND PlanID IN(1, 2, 3) ORDER BY TimePayment DESC LIMIT 1");
							$query->execute();
							
							if ($query->rowCount() > 0) {
								
								$q = $query->fetch(PDO::FETCH_OBJ);
								
								if ($q->PaymentType == 0) {
									
									$customer = \Stripe\Customer::retrieve($myU->StripeKey);
									
									if ($customer->subscriptions->total_count > 0) {
										
										$customer->cancelSubscription();
										
									}
									
								} else if ($q->PaymentType == 1) {
									
									CancelPaypalSubscription($q->SubscriptionID, 'Cancel');
									
								}
							
							}
							
						}
						
						if ($myU->UpgradesCount == 0) {
							
							$Update = $db->prepare("UPDATE User SET CurrencyCoins = CurrencyCoins + 500 WHERE ID = ".$myU->ID."");
							$Update->execute();
							
						}
						
					}
					
						
					$Insert = $db->prepare("INSERT INTO UserPaymentHistory (UserID, PlanID, PaymentType, TimePayment, PayerName, PayerEmail, PayerAddress, PayerCity, PayerState, PayerCountry, TransactionID, LastFour) VALUES(".$myU->ID.", ".$CheckoutPlan.", 2, ".time().", ?, '".$myU->Email."', ?, ?, ?, ?, ?, ?)");
					$Insert->bindValue(1, 'Credits', PDO::PARAM_STR);
					$Insert->bindValue(2, 'Credits', PDO::PARAM_STR);
					$Insert->bindValue(3, 'Credits', PDO::PARAM_STR);
					$Insert->bindValue(4, 'Credits', PDO::PARAM_STR);
					$Insert->bindValue(5, 'Credits', PDO::PARAM_STR);
					$Insert->bindValue(6, 'Credits', PDO::PARAM_STR);
					$Insert->bindValue(7, 0000, PDO::PARAM_STR);
					$Insert->execute();
					
					if (($CheckoutPlan == 1 || $CheckoutPlan == 2 || $CheckoutPlan == 3)) {
						
						$Update = $db->prepare("UPDATE User SET CurrencyCoins = CurrencyCoins + ".$PlanCoins.", NextUpgradeCoinPay = ".(time() + 86400).", VIP = ".$CheckoutPlan.", VIP_Recurring = 0, VIP_Expires = ".$VIPTime." WHERE ID = ".$myU->ID."");
						$Update->execute();
						
						$Insert = $db->prepare("INSERT INTO UserBadge (UserID, AchievementID) VALUES(".$myU->ID.", ".($CheckoutPlan+8).")");
						$Insert->execute();
						
						// Discord verification
						if ($myU->DiscordId > 0 && $myU->VIP == 0) {
							$ch = curl_init();
							curl_setopt($ch, CURLOPT_URL, 'http://discordapi.brickplanet.com/modify-user-vip?userId='.$myU->DiscordId.'&action=add-role&level=' . $CheckoutPlan);
							curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
							$result = curl_exec($ch);
							curl_close($ch);
						} else if ($myU->DiscordId > 0 && $myU->VIP > 0) {
							$ch = curl_init();
							curl_setopt($ch, CURLOPT_URL, 'http://discordapi.brickplanet.com/modify-user-vip?userId='.$myU->DiscordId.'&action=change-role&level=' . $myU->VIP . '&newlevel=' . $CheckoutPlan);
							curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
							$result = curl_exec($ch);
							curl_close($ch);
						}
						
						if ($CheckoutPlan == 1) {
							
							$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 19141");
							$Count->execute();
							$Count = $Count->fetchColumn();
							
							if ($Count == 0) {
								$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 19141, ".time().")");
								$Insert->execute();
							}
							
						} else if ($CheckoutPlan == 2) {
							
							$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18595");
							$Count->execute();
							$Count = $Count->fetchColumn();
							
							if ($Count == 0) {
								$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18595, ".time().")");
								$Insert->execute();
							}
							
							$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18611");
							$Count->execute();
							$Count = $Count->fetchColumn();
							
							if ($Count == 0) {
								$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18611, ".time().")");
								$Insert->execute();
							}
							
						} else if ($CheckoutPlan == 3) {
							
							$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18555");
							$Count->execute();
							$Count = $Count->fetchColumn();
							
							if ($Count == 0) {
								$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18555, ".time().")");
								$Insert->execute();
							}
							
							$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18562");
							$Count->execute();
							$Count = $Count->fetchColumn();
							
							if ($Count == 0) {
								$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18562, ".time().")");
								$Insert->execute();
							}
							
							$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18586");
							$Count->execute();
							$Count = $Count->fetchColumn();
							
							if ($Count == 0) {
								$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18586, ".time().")");
								$Insert->execute();
							}
							
							$Count = $db->prepare("SELECT COUNT(*) FROM UserInventory WHERE UserID = ".$myU->ID." AND ItemID = 18589");
							$Count->execute();
							$Count = $Count->fetchColumn();
							
							if ($Count == 0) {
								$Insert = $db->prepare("INSERT INTO UserInventory (UserID, ItemID, TimeCreated) VALUES(".$myU->ID.", 18589, ".time().")");
								$Insert->execute();
							}
							
						}
						
					} else if (isset($PlanCoins)) {
						
						$Update = $db->prepare("UPDATE User SET CurrencyCoins = CurrencyCoins + ".$PlanCoins." WHERE ID = ".$myU->ID."");
						$Update->execute();
						
					}
					
					$Update = $db->prepare("UPDATE User SET CurrencyCredits = CurrencyCredits - ".(number_format($PlanPrice, 2)*100)." WHERE ID = ".$myU->ID."");
					$Update->execute();
					
					$cache->delete($myU->ID);
					
					header("Location: ".$serverName."/upgrade/success/");
					die;
					
				}
				
				echo '
				<div class="grid-x grid-margin-x">
					<div class="large-6 large-offset-3 cell">
						<h5>You\'re buying (with Credits)</h5>
						<div class="container border-r md-padding">
							<div class="ur-buying-title">'.$PlanName.'</div>
							';
							
							if ($CheckoutPlan == 1 || $CheckoutPlan == 2 || $CheckoutPlan == 3) {
								
								echo '<div class="upgrade-checkout-footnotes">Memberships purchased with Credits do not auto renew.</div>';
								
							}
							
							echo '
							<div class="ur-buying-divider"></div>
							';
							
							if (isset($TimeExtension)) {
								
								echo '
								<div class="grid-x grid-margin-x">
									<div class="auto cell no-margin">
										<strong>Original amount</strong>
									</div>
									<div class="shrink cell right no-margin">
										'.(number_format($PlanPrice+$ProRateCredit)*100).' Credits <font class="sub">($'.(number_format($PlanPrice+$ProRateCredit, 2)).' USD)</font>
									</div>
								</div>
								<div class="grid-x grid-margin-x">
									<div class="auto cell no-margin">
										<strong>Adjustment</strong>
									</div>
									<div class="shrink cell right no-margin">
										- '.number_format($ProRateCredit*100).' Credits <font class="sub">(- $'.(number_format($ProRateCredit, 2)).' USD)</font>
									</div>
								</div>
								<div class="ur-buying-divider"></div>
								';
								
							}
							
							echo '
							<div class="grid-x grid-margin-x">
								<div class="auto cell no-margin">
									<strong>Total due</strong>
								</div>
								<div class="shrink cell right no-margin">
									'.number_format($PlanPrice*100).' Credits <font class="sub">($'.number_format($PlanPrice, 2).' USD)</font>
								</div>
							</div>
							<div class="ur-buying-divider"></div>
							<div class="upgrade-checkout-footnotes">Your remaining Credits balance after this transaction will be <strong>'.number_format($myU->CurrencyCredits - ($PlanPrice*100)).'</strong></div>
						</div>
						<div class="push-25"></div>
						<form action="" method="POST"><div class="text-center"><button type="submit" name="submit" class="button button-green" style="display:inline-block;" value="Complete Transaction">Complete Transaction</button></div></form>
					</div>
				</div>
				';
				
			}
			
		}
		
	}

require_once($_SERVER['DOCUMENT_ROOT']."/../private/footer.php");