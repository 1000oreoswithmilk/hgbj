<?php
$page = 'upgrade';
require_once($_SERVER['DOCUMENT_ROOT']."/../private/header.php");
	
	requireLogin();
	
	if ($SiteSettings->Upgrades == 0) {

		echo '
		<script>
		document.title = "Upgrades - Brick Planet";
		</script>
		<div class="container lg-padding border-r text-center games-construction">
			<i class="material-icons">warning</i>
			<div>This area is under maintenance</div>
			<p>Please contact <a href="mailto:hello@brickplanet.com">hello@brickplanet.com</a> for billing or payment issues.</p>
		</div>
		';
		
		require_once($_SERVER['DOCUMENT_ROOT']."/../private/footer.php");
		
		die;
		
	}
	
	if (isset($_POST['choose_1']) && $myU->VIP == 0) {
		
		$_SESSION['UpgradePlanChoice'] = 1;
		$_SESSION['UpgradeCheckoutPage'] = 1;
		
		header("Location: ".$serverName."/upgrade/checkout");
		die;
		
	} else if (isset($_POST['choose_2']) && $myU->VIP <= 2) {
		
		$_SESSION['UpgradePlanChoice'] = 2;
		$_SESSION['UpgradeCheckoutPage'] = 1;
		
		header("Location: ".$serverName."/upgrade/checkout");
		die;
		
	} else if (isset($_POST['choose_3']) && $myU->VIP <= 3) {
		
		$_SESSION['UpgradePlanChoice'] = 3;
		$_SESSION['UpgradeCheckoutPage'] = 1;
		
		header("Location: ".$serverName."/upgrade/checkout");
		die;
		
	}
	
	echo '
	<script>document.title = "Upgrade - Brick Planet";</script>
	<div class="grid-x grid-margin-x">
		<div class="large-9 upgrade-offset cell">
			<div class="grid-x grid-margin-x">
				<div class="auto cell no-margin">
					<h4>Upgrades</h4>
				</div>
				<div class="shrink cell right">
					<a href="'.$serverName.'/upgrade/bits" class="button button-green">Buy Bits</a>
				</div>
				<div class="shrink cell right no-margin">
					<a href="'.$serverName.'/upgrade/credits" class="button button-grey">Buy Credits</a>
				</div>
				<div class="shrink cell right">
					<a href="'.$serverName.'/upgrade/code-redemption" class="button button-grey">Redeem Codes</a>
				</div>
			</div>
		</div>
	</div>
	<div class="push-25"></div>
	<div class="upgrade-title">MEMBERSHIPS</div>
	<div class="push-25"></div>
	<div class="grid-x grid-margin-x">
		<div class="large-3 medium-4 small-6 upgrade-offset cell">
			<div class="container border-r">
				<div class="push-15"></div>
				<div class="upgrade-card-image" style="background:url('.$cdnName.'assets/images/profile/01cf8ba45a61b55fc6ca8b1d48d0c8fa.svg);"></div>
				<div class="upgrade-card-title">Brick Builder</div>
				<div class="upgrade-card-price">$4.95/mo</div>
				<div class="upgrade-card-inner">
					<div class="upgrade-card-info"><strong>100</strong> Bits per day</div>
					<div class="upgrade-card-info">Create up to <strong>15</strong> games</div>
					<div class="upgrade-card-info">Create or join up to <strong>15</strong> groups</div>
				</div>
				<div class="upgrade-card-divider"></div>
				<div class="upgrade-card-button">
					<form action="" method="POST">
						<button type="submit" class="button button-green" name="choose_1"'; if ($myU->VIP >= 1) { echo ' disabled><span data-tooltip aria-haspopup="true" class="has-tip" data-disable-hover="false" tabindex="1" title="You can not downgrade an existing membership.">Choose</span>'; } else { echo '>Choose'; } echo '</button>
					</form>
				</div>
			</div>
		</div>
		<div class="large-3 medium-4 small-6 cell">
			<div class="container border-r">
				<div class="push-15"></div>
				<div class="upgrade-card-image" style="background:url('.$cdnName.'assets/images/profile/5e1495b296b08ba947fcd310bd8bbca4.svg);"></div>
				<div class="upgrade-card-title">Planet Constructor</div>
				<div class="upgrade-card-price">$11.95/mo</div>
				<div class="upgrade-card-inner">
					<div class="upgrade-card-info"><strong>200</strong> Bits per day</div>
					<div class="upgrade-card-info">Create up to <strong>30</strong> games</div>
					<div class="upgrade-card-info">Create or join up to <strong>30</strong> groups</div>
				</div>
				<div class="upgrade-card-divider"></div>
				<div class="upgrade-card-button">
					<form action="" method="POST">
						<button type="submit" class="button button-green" name="choose_2"'; if ($myU->VIP >= 2) { echo ' disabled><span data-tooltip aria-haspopup="true" class="has-tip" data-disable-hover="false" tabindex="1" title="You can not downgrade an existing membership.">Choose</span>'; } else { echo '>Choose'; } echo '</button>
					</form>
				</div>
			</div>
		</div>
		<div class="large-3 medium-4 small-6 small-offset-3 medium-offset-0 large-offset-0 cell">
			<div class="push-25 show-for-small-only"></div>
			<div class="container border-r">
				<div class="push-15"></div>
				<div class="upgrade-card-image" style="background:url('.$cdnName.'assets/images/profile/7d36601a66b9151fd2675d1a80a3920e.svg);"></div>
				<div class="upgrade-card-title">Master Architect</div>
				<div class="upgrade-card-price">$18.95/mo</div>
				<div class="upgrade-card-inner">
					<div class="upgrade-card-info"><strong>300</strong> Bits per day</div>
					<div class="upgrade-card-info">Create up to <strong>100</strong> games</div>
					<div class="upgrade-card-info">Create or join up to <strong>50</strong> groups</div>
				</div>
				<div class="upgrade-card-divider"></div>
				<div class="upgrade-card-button">
					<form action="" method="POST">
						<button type="submit" class="button button-green" name="choose_3"'; if ($myU->VIP >= 3) { echo ' disabled><span data-tooltip aria-haspopup="true" class="has-tip" data-disable-hover="false" tabindex="1" title="You can not downgrade an existing membership.">Choose</span>'; } else { echo '>Choose'; } echo '</button>
					</form>
				</div>
			</div>
		</div>
	</div>
	';

require_once($_SERVER['DOCUMENT_ROOT']."/../private/footer.php");