<?php
$page = 'upgrade';
require_once($_SERVER['DOCUMENT_ROOT']."/../private/header.php");

	if (isset($_POST['choose_1'])) {
		
		$_SESSION['UpgradePlanChoice'] = 4;
		$_SESSION['UpgradeCheckoutPage'] = 1;

		header("Location: ".$serverName."/upgrade/checkout");
		die;

	} else if (isset($_POST['choose_2'])) {

		$_SESSION['UpgradePlanChoice'] = 5;
		$_SESSION['UpgradeCheckoutPage'] = 1;

		header("Location: ".$serverName."/upgrade/checkout");
		die;

	} else if (isset($_POST['choose_3'])) {

		$_SESSION['UpgradePlanChoice'] = 6;
		$_SESSION['UpgradeCheckoutPage'] = 1;

		header("Location: ".$serverName."/upgrade/checkout");
		die;

	} else if (isset($_POST['choose_4'])) {

		$_SESSION['UpgradePlanChoice'] = 7;
		$_SESSION['UpgradeCheckoutPage'] = 1;

		header("Location: ".$serverName."/upgrade/checkout");
		die;

	} else if (isset($_POST['choose_5'])) {

		$_SESSION['UpgradePlanChoice'] = 8;
		$_SESSION['UpgradeCheckoutPage'] = 1;

		header("Location: ".$serverName."/upgrade/checkout");
		die;

	} else if (isset($_POST['choose_6'])) {

		$_SESSION['UpgradePlanChoice'] = 9;
		$_SESSION['UpgradeCheckoutPage'] = 1;

		header("Location: ".$serverName."/upgrade/checkout");
		die;

	} else if (isset($_POST['choose_7'])) {

		$_SESSION['UpgradePlanChoice'] = 10;
		$_SESSION['UpgradeCheckoutPage'] = 1;

		header("Location: ".$serverName."/upgrade/checkout");
		die;

	}

	echo '
	<h4>Bit Packages</h4>
	<div class="push-25"></div>
	<div class="grid-x grid-margin-x">
		<div class="large-3 medium-3 small-6 cell">
			<div class="container border-r">
				<div class="push-15"></div>
				<div class="text-center"><img src="'.$serverName.'/assets/images/bits.png"></div>
				<div class="upgrade-card-title">1,000 Bits</div>
				<div class="upgrade-card-price">$0.99</div>
				<div class="upgrade-card-button">
					<form action="" method="POST">
						<input type="submit" class="button button-green" name="choose_1" value="Choose">
					</form>
				</div>
			</div>
			<div class="push-50 show-for-small-only"></div>
		</div>
		<div class="large-3 medium-3 small-6 cell">
			<div class="container border-r">
				<div class="push-15"></div>
				<div class="text-center"><img src="'.$serverName.'/assets/images/bits.png"></div>
				<div class="upgrade-card-title">5,000 Bits</div>
				<div class="upgrade-card-price">$4.99</div>
				<div class="upgrade-card-button">
					<form action="" method="POST">
						<input type="submit" class="button button-green" name="choose_2" value="Choose">
					</form>
				</div>
			</div>
		</div>
		<div class="large-3 medium-3 small-6 cell">
			<div class="container border-r">
				<div class="push-15"></div>
				<div class="text-center"><img src="'.$serverName.'/assets/images/bits.png"></div>
				<div class="upgrade-card-title">10,000 Bits</div>
				<div class="upgrade-card-price">$9.99</div>
				<div class="upgrade-card-button">
					<form action="" method="POST">
						<input type="submit" class="button button-green" name="choose_3" value="Choose">
					</form>
				</div>
			</div>
		</div>
		<div class="large-3 medium-3 small-6 cell">
			<div class="container border-r">
				<div class="push-15"></div>
				<div class="text-center"><img src="'.$serverName.'/assets/images/bits.png"></div>
				<div class="upgrade-card-title">25,000 Bits</div>
				<div class="upgrade-card-price">$24.99</div>
				<div class="upgrade-card-button">
					<form action="" method="POST">
						<input type="submit" class="button button-green" name="choose_4" value="Choose">
					</form>
				</div>
			</div>
		</div>
	</div>
	<div class="push-50"></div>
	<div class="grid-x grid-margin-x">
		<div class="large-3 medium-3 small-6 upgrade-offset cell">
			<div class="container border-r">
				<div class="push-15"></div>
				<div class="text-center"><img src="'.$serverName.'/assets/images/bits.png"></div>
				<div class="upgrade-card-title">51,000 Bits</div>
				<div class="upgrade-card-price">$49.99</div>
				<div class="upgrade-card-button">
					<form action="" method="POST">
						<input type="submit" class="button button-green" name="choose_5" value="Choose">
					</form>
				</div>
			</div>
			<div class="push-50 show-for-small-only"></div>
		</div>
		<div class="large-3 medium-3 small-6 cell">
			<div class="container border-r">
				<div class="push-15"></div>
				<div class="text-center"><img src="'.$serverName.'/assets/images/bits.png"></div>
				<div class="upgrade-card-title">105,000 Bits</div>
				<div class="upgrade-card-price">$99.99</div>
				<div class="upgrade-card-button">
					<form action="" method="POST">
						<input type="submit" class="button button-green" name="choose_6" value="Choose">
					</form>
				</div>
			</div>
		</div>
		<div class="large-3 medium-3 small-6 small-offset-3 medium-offset-0 large-offset-0 cell">
			<div class="container border-r">
				<div class="push-15"></div>
				<div class="text-center"><img src="'.$serverName.'/assets/images/bits.png"></div>
				<div class="upgrade-card-title">160,000 Bits</div>
				<div class="upgrade-card-price">$149.99</div>
				<div class="upgrade-card-button">
					<form action="" method="POST">
						<input type="submit" class="button button-green" name="choose_7" value="Choose">
					</form>
				</div>
			</div>
		</div>
	</div>
	';

require_once($_SERVER['DOCUMENT_ROOT']."/../private/footer.php");
